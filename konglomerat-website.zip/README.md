# Konglomerat Website

A corporate-style website inspired by conglomerate businesses.

## Features
- Multi-sector grid layout
- Warm corporate gradient
- Clean and modern UI

## How to Run
Open index.html in your browser.

## Author
Generated with ChatGPT
